/* 
   Copyright Albert L Faber (c) 2000

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "StdAfx.h"
#include "ISndStream.h"


// CONSTRUCTOR
ISndStream::ISndStream()
	:SndStream()
{
	m_dwBitRate=0;
}

// DESRUCTOR
ISndStream::~ISndStream()
{
}


DWORD ISndStream::Read(PBYTE pbData,DWORD dwNumBytes)
{
	ASSERT(FALSE);
	return 0;
}

DWORD ISndStream::GetTotalTime()
{
	/* total file length in ms */
	return 0;
}

DWORD ISndStream::GetCurrentTime()
{
	/* total file length in ms */
	return 0;
}

LONG ISndStream::Seek( LONG lOff, UINT nFrom )
{
	return -1;
}

void ISndStream::Flush()
{
	return ;
}

void ISndStream::InfoBox( HWND hWnd)
{
	return ;
}

void ISndStream::Pause()
{
	return ;
}

