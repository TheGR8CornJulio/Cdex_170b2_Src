#ifndef HIST_EDIT_H_INCLUDED
#define HIST_EDIT_H_INCLUDED


class CHistEdit : public CEdit
{
	CString m_strHist;
	int		m_nLines;
	int		m_nHistLines;
	CString	m_strLogFileName;
	bool	m_bLogEnabled;

public:
	// CONSTRUCTOR
	CHistEdit();

	// DESTRUCTOR
	virtual ~CHistEdit();

	// METHODS
	void AddString(const CString& strAdd, bool bAddReturn= TRUE);

	void SetNumHistLines(int nValue) {m_nHistLines=nValue;}
	int  GetNumHistLines() const {return m_nHistLines;}
	void SetLogging( const CString& strFileName, bool bEnable );

};


#endif
