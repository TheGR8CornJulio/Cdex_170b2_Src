#ifndef CDDBSUBMITSOPTS_H_INCLUDED
#define CDDBSUBMITSOPTS_H_INCLUDED

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// CDDBSubmitOpts.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCDDBSubmitOpts dialog

class CCDDBSubmitOpts : public CDialog
{
// Construction
public:
	CCDDBSubmitOpts(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCDDBSubmitOpts)
	enum { IDD = IDD_SUBMITOPTS };
	CString	m_strEmailAddress;
	CString	m_strHTMLAddress;
	int		m_nSubmitVia;
	CString	m_strSMTPServer;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCDDBSubmitOpts)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCDDBSubmitOpts)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif

