#ifndef ISndStream_H_INCLUDED
#define ISndStream_H_INCLUDED

#include "SndStream.h"

class ISndStream:public SndStream
{
public:
	// DESTRUCTOR
	virtual ~ISndStream();

	// MUTATORS
	virtual DWORD	Read(PBYTE pbData,DWORD dwNumBytes);
	virtual DWORD	GetTotalTime();						/* total file length in ms */
	virtual DWORD	GetCurrentTime();						/* total file length in ms */
	virtual LONG	Seek( LONG lOff, UINT nFrom );
	virtual void	Flush();
	virtual void	Pause();
	virtual VOID	InfoBox( HWND hWnd );

	// ACCESSORS
	virtual DWORD	GetBitRate(void) {return m_dwBitRate;}
	virtual void	SetBitRate(DWORD nValue) {m_dwBitRate=nValue;}

protected:
	// CONSTRUCTOR, ABSTRACT CLASS
	ISndStream();
private:
	DWORD			m_dwBitRate;
};




#endif