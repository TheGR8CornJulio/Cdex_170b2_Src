#if !defined(AFX_CDRDAO_H__5F7BD380_2C64_11D5_A2DB_005004EF8536__INCLUDED_)
#define AFX_CDRDAO_H__5F7BD380_2C64_11D5_A2DB_005004EF8536__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include "ChildProcess.h"
#include "HistEdit.h"

// CdrDao.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCdrDao dialog

class CCdrDao : public CDialog
{
// Construction
public:
	CCdrDao(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCdrDao)
	enum { IDD = IDD_CDRDAO };
	CHistEdit	m_OutputWnd;
	CComboBox	m_cdDrives;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCdrDao)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCdrDao)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	HANDLE			m_hInReadPipe;
	HANDLE			m_hInWritePipe;
	HANDLE			m_hOutReadPipe;
	HANDLE			m_hOutWritePipe;
	HANDLE			m_hErrPipe;
	CChildProcess*	m_pChildProcess;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDRDAO_H__5F7BD380_2C64_11D5_A2DB_005004EF8536__INCLUDED_)
