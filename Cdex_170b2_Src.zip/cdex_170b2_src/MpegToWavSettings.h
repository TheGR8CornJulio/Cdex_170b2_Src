#if !defined(AFX_MPEGTOWAVSETTINGS_H__185B94A1_325D_11D5_A2DB_005004EF8536__INCLUDED_)
#define AFX_MPEGTOWAVSETTINGS_H__185B94A1_325D_11D5_A2DB_005004EF8536__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MpegToWavSettings.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMpegToWavSettings dialog

class CMpegToWavSettings : public CDialog
{
// Construction
public:
	CMpegToWavSettings(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMpegToWavSettings)
	enum { IDD = IDD_MPEGTOWAVSETTINGS };
	CComboBox	m_OutFrequency;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMpegToWavSettings)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMpegToWavSettings)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MPEGTOWAVSETTINGS_H__185B94A1_325D_11D5_A2DB_005004EF8536__INCLUDED_)
