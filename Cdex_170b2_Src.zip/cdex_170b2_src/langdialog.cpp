// LangDialog.cpp : implementation file
//

#include "stdafx.h"
#include "cdex.h"
#include "LangDialog.h"
#include "Util.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLangDialog dialog


CLangDialog::CLangDialog(UINT nIDTemplate, CWnd* pParent )
	: CDialog( nIDTemplate, pParent )
{
	//{{AFX_DATA_INIT(CLangDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nIDTemplate = nIDTemplate;
}

CLangDialog::~CLangDialog( )
{
}


void CLangDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLangDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLangDialog, CDialog)
	//{{AFX_MSG_MAP(CLangDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLangDialog message handlers

BOOL CLangDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// translate dialog resources
	g_language.InitDialogStrings( this, (long)m_nIDTemplate );
		
	return TRUE;
}

