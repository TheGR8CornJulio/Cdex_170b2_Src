this is the README file for the vornis library directory of the CDex source code repository.
the DLL's are included in the installer script.

The ogg vorbis libraries are licensed and distributed under a BSD-like license. The full
text can be found in CVS at
Copying.Ogg-Vorbis

The source code used to build is available on the developer's site, at
http://www.xiph.org

The OggVorbis source code is (C) Copyright 1994-2001 by the XIPHOPHORUS Company
