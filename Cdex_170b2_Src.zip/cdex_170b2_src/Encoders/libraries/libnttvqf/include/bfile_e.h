/* (c)Copyright 1996-2000 NTT Cyber Space Laboratories */
/*                Released on 2000.05.22 by N. Iwakami */

#ifndef bfile_e_h
#define bfile_e_h

#include "bfile.h"

extern int put_strm(int   data,          /* Input: input data */
		    int   nbits,         /* Input: number of bits */
		    BFILE *bfp);          /* Input: bit file pointer */


#endif
