/*
** Copyright (C) 1999 - 2002 Albert L. Faber
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef GENERICPROPPAGE_H_INCLUDED
#define GENERICPROPPAGE_H_INCLUDED

#include "ddxgetfolder.h"
#include "resource.h"


/////////////////////////////////////////////////////////////////////////////
// CGenericPropPage dialog

class CGenericPropPage : public CPropertyPage
{
private:
	DECLARE_DYNCREATE(CGenericPropPage)
	CString	m_strTitle;
public:
	// CONSTRUCTOR
	CGenericPropPage();

	// DESTRUCTOR
	~CGenericPropPage();

	// MUTATORS
	afx_msg BOOL OnApply();
	void UpdateControls();

	CGetFolderControl m_tmpDir;

// Dialog Data
	//{{AFX_DATA(CGenericPropPage)
	enum { IDD = IDD_GENERICPROPPAGE };
	BOOL	m_bNormTrack;
	int		m_nLNormLevel;
	int		m_nUNormLevel;
	CComboBox	m_ID3Version;
	CString	m_strComment;
	CString	m_strEncodedBy;
	int		m_nLNormFactor;
	int		m_nHNormFactor;
	BOOL	m_bAutoShutDown;
	int		m_nID3V2TrkNrType;
	BOOL	m_bDigitalCDPlay;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CGenericPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CGenericPropPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	afx_msg void ID3VersionChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


#endif
