// MpegToWavSettings.cpp : implementation file
//

#include "stdafx.h"
#include "cdex.h"
#include "MpegToWavSettings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMpegToWavSettings dialog


CMpegToWavSettings::CMpegToWavSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CMpegToWavSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMpegToWavSettings)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMpegToWavSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMpegToWavSettings)
	DDX_Control(pDX, IDC_OUTFREQ, m_OutFrequency);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMpegToWavSettings, CDialog)
	//{{AFX_MSG_MAP(CMpegToWavSettings)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMpegToWavSettings message handlers
